﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vanguard_ui_v2
{
    public partial class MainWindow : Form
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MainWindow_Load(object sender, EventArgs e)
        {
            this.LoginWorker.RunWorkerAsync();
        }

        private void LoginWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            this.StatusWorker.RunWorkerAsync();

            if (!Vanguard.Login())
            {
                this.Invoke((MethodInvoker)delegate ()
                {
                    this.StatusLbl.Text = "Login Failed";
                });

                this.StatusWorker.CancelAsync();
                this.PBar.Style = ProgressBarStyle.Continuous;
                this.PBar.Value = 100;
                return;
            }

            this.StatusWorker.CancelAsync();

            this.Invoke((MethodInvoker)delegate ()
            {
                this.PBar.Style = ProgressBarStyle.Continuous;
                this.PBar.Value = 100;

                string username = Vanguard.Username();
                this.StatusLbl.Text = "Welcome " + char.ToUpper(username[0]) + username.Substring(1);

                foreach (string module in Vanguard.Modules())
                {
                    this.ModuleLBox.Items.Add(module.Replace(".dll", ""));
                }

            });
        }

        private void StatusWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            while (!this.StatusWorker.CancellationPending)
            {
                this.Invoke((MethodInvoker)delegate ()
                {
                    this.StatusLbl.Text = Vanguard.Status();
                });

                System.Threading.Thread.Sleep(500);
            }

            e.Cancel = true;
            return;
        }

        private void InjectWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            this.StatusWorker.RunWorkerAsync();
            string moduleName = e.Argument as string;

            if (Vanguard.Inject(moduleName))
            {
                this.PBar.Style = ProgressBarStyle.Continuous;
                this.PBar.Value = 100;
                MessageBox.Show("Injection Succeeded!", "Vanguard", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            else
            {
                this.PBar.Style = ProgressBarStyle.Continuous;
                this.PBar.Value = 100;
                MessageBox.Show("Injection Failed!", "Vanguard", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            this.StatusWorker.CancelAsync();
        }

        private void InjectBtn_Click(object sender, EventArgs e)
        {
            if (this.ModuleLBox.SelectedIndex < 0)
                MessageBox.Show("Select a module first!");

            this.PBar.Style = ProgressBarStyle.Marquee;
            this.PBar.Value = 0;

            string moduleName = this.ModuleLBox.SelectedItem.ToString() + ".dll";
            InjectWorker.RunWorkerAsync(moduleName);
        }
    }
}
