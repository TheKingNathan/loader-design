﻿namespace vanguard_ui_v2
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StatusLbl = new System.Windows.Forms.Label();
            this.LoginWorker = new System.ComponentModel.BackgroundWorker();
            this.StatusWorker = new System.ComponentModel.BackgroundWorker();
            this.PBar = new System.Windows.Forms.ProgressBar();
            this.ModuleLBox = new System.Windows.Forms.ListBox();
            this.InjectBtn = new System.Windows.Forms.Button();
            this.InjectWorker = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // StatusLbl
            // 
            this.StatusLbl.AutoSize = true;
            this.StatusLbl.Location = new System.Drawing.Point(13, 373);
            this.StatusLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.StatusLbl.Name = "StatusLbl";
            this.StatusLbl.Size = new System.Drawing.Size(54, 20);
            this.StatusLbl.TabIndex = 0;
            this.StatusLbl.Text = "Status:";
            // 
            // LoginWorker
            // 
            this.LoginWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.LoginWorker_DoWork);
            // 
            // StatusWorker
            // 
            this.StatusWorker.WorkerSupportsCancellation = true;
            this.StatusWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.StatusWorker_DoWork);
            // 
            // PBar
            // 
            this.PBar.Location = new System.Drawing.Point(12, 396);
            this.PBar.MarqueeAnimationSpeed = 30;
            this.PBar.Name = "PBar";
            this.PBar.Size = new System.Drawing.Size(544, 23);
            this.PBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.PBar.TabIndex = 1;
            // 
            // ModuleLBox
            // 
            this.ModuleLBox.FormattingEnabled = true;
            this.ModuleLBox.ItemHeight = 20;
            this.ModuleLBox.Location = new System.Drawing.Point(12, 12);
            this.ModuleLBox.Name = "ModuleLBox";
            this.ModuleLBox.Size = new System.Drawing.Size(544, 284);
            this.ModuleLBox.TabIndex = 2;
            // 
            // InjectBtn
            // 
            this.InjectBtn.Location = new System.Drawing.Point(12, 316);
            this.InjectBtn.Name = "InjectBtn";
            this.InjectBtn.Size = new System.Drawing.Size(544, 34);
            this.InjectBtn.TabIndex = 3;
            this.InjectBtn.Text = "Inject";
            this.InjectBtn.UseVisualStyleBackColor = true;
            this.InjectBtn.Click += new System.EventHandler(this.InjectBtn_Click);
            // 
            // InjectWorker
            // 
            this.InjectWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.InjectWorker_DoWork);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(568, 431);
            this.Controls.Add(this.InjectBtn);
            this.Controls.Add(this.ModuleLBox);
            this.Controls.Add(this.PBar);
            this.Controls.Add(this.StatusLbl);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "MainWindow";
            this.Text = "Vanguard v2";
            this.Load += new System.EventHandler(this.MainWindow_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label StatusLbl;
        private System.ComponentModel.BackgroundWorker LoginWorker;
        private System.ComponentModel.BackgroundWorker StatusWorker;
        private System.Windows.Forms.ProgressBar PBar;
        private System.Windows.Forms.ListBox ModuleLBox;
        private System.Windows.Forms.Button InjectBtn;
        private System.ComponentModel.BackgroundWorker InjectWorker;
    }
}

