﻿using System;
using System.Runtime.InteropServices;

namespace vanguard_ui_v2
{
    class Vanguard
    {
        [DllImport("vanguard.dll", SetLastError = true, CallingConvention = CallingConvention.Cdecl)]
        public static extern bool Login();

        [DllImport("vanguard.dll", SetLastError = true, CallingConvention = CallingConvention.Cdecl)]
        public static extern bool Logout();

        [DllImport("vanguard.dll", SetLastError = true, CallingConvention = CallingConvention.Cdecl)]
        public static extern bool Inject(string modName, bool _ignore_ = false);

        [DllImport("vanguard.dll", SetLastError = true, CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr GetUsername();

        [DllImport("vanguard.dll", SetLastError = true, CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr GetModuleList();

        [DllImport("vanguard.dll", SetLastError = true, CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr GetStatus();

        [DllImport("vanguard.dll", SetLastError = true, CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr GetLastLog();

        [DllImport("vanguard.dll", SetLastError = true, CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr GetLoadLibraryPath();

        Vanguard()
        {

        }

        public static string Username()
        {
            return Marshal.PtrToStringAnsi(GetUsername());
        }

        public static string[] Modules()
        {
            string modules = Marshal.PtrToStringAnsi(GetModuleList());
            return modules.Split(new string[] { "##" }, StringSplitOptions.None);
        }

        public static string Status()
        {
            return Marshal.PtrToStringAnsi(GetStatus());
        }

        public static string LastLog()
        {
            return Marshal.PtrToStringAnsi(GetLastLog());
        }

        public static string LoadLibraryPath()
        {
            return Marshal.PtrToStringAnsi(GetLoadLibraryPath());
        }

        // The following 3 methods are for backwards compatibility only
        // as the injection functionality was merged into a single ``Inject`` call
        public static bool InjectModule(string module)
        {
            return Inject(module);
        }

        public static bool InjectLL(string module, string _useless_)
        {
            return Inject(module);
        }

        public static bool InjectProxy(string module, string _useless_)
        {
            return Inject(module);
        }
    }
}
